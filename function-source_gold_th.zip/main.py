import requests
import psycopg2
from datetime import datetime
from bs4 import BeautifulSoup
import functions_framework

@functions_framework.http
def scrape_gold_price(request):
    url = 'https://www.goldtraders.or.th/'
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    span_element = soup.find('span', id='DetailPlace_uc_goldprices1_lblBLSell')
    price = float(span_element.get_text(strip=True).replace(',', '')) if span_element else None

    if price:
        save_gold_price_to_db(price)  # บันทึกราคาทองคำลงฐานข้อมูล
        return f"บันทึกราคาทองคำ: {price}"
    else:
        return "ไม่พบข้อมูลราคาทองคำ"

def connect_db():
    return psycopg2.connect(
        host="35.223.225.122",
        database="GoldPredictSystemDB",
        user="Booth",
        password="Toon",
        port="5432"
    )

def save_gold_price_to_db(price):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('SELECT price FROM public."Gold_US_goldprice" ORDER BY date DESC LIMIT 1')
    last_price = cursor.fetchone()
    
    last_price = float(last_price[0]) if last_price else None
    price_diff = price - last_price if last_price else None
    price_diff_percent = (price_diff / last_price) * 100 if last_price else None

    sql = '''INSERT INTO public."Gold_US_goldprice" (date, price, price_diff_unit, price_diff_percent)
             VALUES (%s, %s, %s, %s)'''
    cursor.execute(sql, (datetime.now(), price, price_diff, price_diff_percent))
    conn.commit()
    cursor.close()
    conn.close()

import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import psycopg2
import functions_framework

db_config = {
    "host": "35.223.225.122",
    "database": "GoldPredictSystemDB",
    "user": "Booth",
    "password": "Toon",
    "port": "5432"
}

def save_log(name, message, status):
    try:
        connection = psycopg2.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute('''
            INSERT INTO public.logs ("timestamp", name, message, status)
            VALUES (NOW(), %s, %s, %s);
        ''', (name, message, status))
        connection.commit()
    except Exception as e:
        print(f"Error saving log to database: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_latest_db_data():
    try:
        connection = psycopg2.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM public."Gold_US_goldpriceus" ORDER BY "date" DESC LIMIT 1;')
        latest_data = cursor.fetchone()

        if latest_data:
            return {
                "date": latest_data[1].isoformat(),
                "price": float(latest_data[2]),
                "open": float(latest_data[3]),
                "high": float(latest_data[4]),
                "low": float(latest_data[5]),
                "volume": float(latest_data[6]),
                "percent": float(latest_data[7]),
                "unitUSD": float(latest_data[8]),
                "unitTHB": float(latest_data[9]),
            }
    except Exception as e:
        print(f"Error fetching latest data from database: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
    return None

def get_today_data():
    url = 'https://th.investing.com/currencies/xau-usd-historical-data'
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()
    soup = BeautifulSoup(response.content, 'html.parser')
    data_rows = soup.find_all('tr', class_='historical-data-v2_price__atUfP')

    for data_row in data_rows:
        date_str = data_row.find('time').text
        date = datetime.strptime(date_str, '%b %d, %Y').date()
        price = float(data_row.find_all('td')[1].text.replace(',', '') or 0)
        latest_open = float(data_row.find_all('td')[2].text.replace(',', '') or 0)
        high = float(data_row.find_all('td')[3].text.replace(',', '') or 0)
        low = float(data_row.find_all('td')[4].text.replace(',', '') or 0)
        volume = float(data_row.find_all('td')[5].text.replace(',', '') or 0)
        percent = float(data_row.find_all('td')[6].text.replace('%', '') or 0)

        if date == datetime.now().date():
            return {
                "date": date.isoformat(),
                "price": price,
                "open": latest_open,
                "high": high,
                "low": low,
                "volume": volume,
                "percent": percent,
                "unitUSD": 0.00,
                "unitTHB": 0.00
            }
    return None

def save_today_data(data):
    """บันทึกข้อมูลราคาทองลงในฐานข้อมูล"""
    try:
        connection = psycopg2.connect(**db_config)
        cursor = connection.cursor()
        cursor.execute('''
            INSERT INTO public."Gold_US_goldpriceus" ("date", "price", "open", "high", "low", "volume", "percent", "unitUSD", "unitTHB")
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);
        ''', (data["date"], data["price"], data["open"], data["high"], data["low"], data["volume"], data["percent"], data["unitUSD"], data["unitTHB"]))
        connection.commit()
    except Exception as e:
        print(f"Error saving today's data to database: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@functions_framework.http
def main(request):
    try:
        latest_db_data = get_latest_db_data()
        if latest_db_data:
            save_log("Gold US", "Fetched database.", "SUCCESS")
        else:
            save_log("Gold US", "Failed fetch database.", "ERROR")

        today_data = get_today_data()
        if today_data:
            save_log("Gold US", "Fetched", "SUCCESS")
        else:
            save_log("Gold US", "Failed fetch", "ERROR")

        if latest_db_data and today_data:
            today_data["unitUSD"] = round(today_data["price"] - latest_db_data["price"], 2)
            today_data["unitTHB"] = round(today_data["unitTHB"], 2)
            save_today_data(today_data)
            save_log("Gold US", "Saved", "SUCCESS")

        response_data = {
            "latest": latest_db_data,
            "today": today_data
        }

        return json.dumps(response_data), 200

    except Exception as e:
        save_log("Gold US", f"An error occurred: {str(e)}", "ERROR")
        return json.dumps({"error": "An internal error occurred."}), 500

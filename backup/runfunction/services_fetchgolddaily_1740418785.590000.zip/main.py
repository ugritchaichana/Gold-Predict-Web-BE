import requests
import logging
from google.cloud import logging as gcloud_logging
import functions_framework

# Set up Google Cloud Logging
client = gcloud_logging.Client()
client.setup_logging()

# URLs
backend_url = "http://35.197.132.241:8000/"
currency_url = "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json"
add_currency_url = f"{backend_url}currency/add-crrencyth/"
gold_data_urls = [
    f"{backend_url}finnomenaGold/fetch-gold-data/?db_choice=0",
    f"{backend_url}finnomenaGold/fetch-gold-data/?db_choice=1"
]

@functions_framework.http
def fetch_and_post_data(request):
    """HTTP Cloud Function to fetch data and post it.
    
    Args:
        request (flask.Request): The request object.
        
    Returns:
        The response text.
    """
    try:
        # Trigger gold data fetch
        for url in gold_data_urls:
            try:
                gold_response = requests.get(url)
                if gold_response.status_code == 200:
                    logging.info(f"Successfully triggered gold data fetch: {url}")
                    logging.info(f"Response Data: {gold_response.json()}")  # Log the response data
                else:
                    logging.error(f"Failed to trigger gold data fetch: {url}, Status code: {gold_response.status_code}")
                    logging.error(f"Error Response: {gold_response.text}")  # Log the error message
            except requests.RequestException as e:
                logging.error(f"Request to {url} failed: {e}")

        # Request data from the external currency API
        response = requests.get(currency_url)

        if response.status_code == 200:
            data = response.json()
            date = data.get('date')
            thb = data.get('usd', {}).get('thb')
            
            if date and thb:
                # Log successful retrieval
                logging.info(f"Date: {date}, THB: {thb}")
                
                # Create payload for the POST request
                payload = {'date': date, 'price': thb}
                
                # Post data to the server
                post_response = requests.post(add_currency_url, json=payload)
                logging.info(f"POST status code: {post_response.status_code}")
                
                if post_response.status_code == 201:
                    logging.info("Data added successfully!")
                    return 'Data added successfully!', 200
                else:
                    logging.error(f"Failed to add data. Status code: {post_response.status_code} {post_response.text}")
                    return f"Failed to add data. Status code: {post_response.status_code}", 400
            else:
                logging.error("Currency data is missing 'date' or 'thb' field.")
                return "Currency data is missing 'date' or 'thb' field.", 400
        else:
            logging.error(f"Failed to retrieve data. Status code: {response.status_code}")
            return f"Failed to retrieve data. Status code: {response.status_code}", 400

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return f"An error occurred: {str(e)}", 500
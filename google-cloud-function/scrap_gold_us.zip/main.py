import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime, timedelta

# ฟังก์ชันดึงข้อมูลล่าสุดจาก API สำหรับ 3 วัน
def get_last_3_days_data_from_api():
    today = datetime.today().date()
    three_days_ago = today - timedelta(days=3)
    
    url = f"http://104.198.31.210:8000/gold/list/?gold_currency=usd&start_date={three_days_ago}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data:
            return data[-3:]  # ดึงข้อมูล 3 วันที่ผ่านมา
    else:
        print(f"Error fetching data from API: {response.status_code}")
    return None

# ฟังก์ชันดึงข้อมูลราคาทองคำวันนี้จากเว็บไซต์ (Web Scraping)
def get_today_data():
    url = 'https://th.investing.com/currencies/xau-usd-historical-data'
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()  # หากเกิดข้อผิดพลาดจะหยุดทำงาน
    soup = BeautifulSoup(response.content, 'html.parser')
    data_rows = soup.find_all('tr', class_='historical-data-v2_price__atUfP')

    for data_row in data_rows:
        date_str = data_row.find('time').text
        date = datetime.strptime(date_str, '%b %d, %Y').date()
        price = float(data_row.find_all('td')[1].text.replace(',', '') or 0)
        latest_open = float(data_row.find_all('td')[2].text.replace(',', '') or 0)
        high = float(data_row.find_all('td')[3].text.replace(',', '') or 0)
        low = float(data_row.find_all('td')[4].text.replace(',', '') or 0)
        percent = float(data_row.find_all('td')[6].text.replace('%', '') or 0)

        # ถ้าวันนี้เป็นวันที่แสดงข้อมูล
        if date == datetime.now().date():
            return {
                "gold_currency": "usd",
                "date": date.isoformat(),
                "price": price,
                "open": latest_open,
                "high": high,
                "low": low,
                "percent": percent,
                "diff": 0.0  # ค่า diff จะคำนวณจากข้อมูลล่าสุด
            }
    return None

# ฟังก์ชันบันทึกข้อมูลราคาทองคำวันนี้ไปยัง API
def save_today_data_to_api(today_data):
    url = "http://104.198.31.210:8000/gold/create/"
    headers = {
        "Content-Type": "application/json"
    }

    # แสดงข้อมูลที่ส่งไปก่อน
    print(f"Sending data: {today_data}")
    
    response = requests.post(url, json=today_data, headers=headers)

    # แสดง response status code และข้อความ
    print(f"Response status code: {response.status_code}")
    print(f"Response text: {response.text}")
    
    if response.status_code == 201:
        print("Today data saved successfully.")
        return response.json()  # คืนค่า response.json() ที่ได้จากการบันทึกข้อมูล
    else:
        print(f"Error saving today's data: {response.status_code}, {response.text}")
    return None


# ฟังก์ชันบันทึกข้อมูล logs
def save_log_to_api(log_data):
    url = "http://104.198.31.210:8000/api/logs/"
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=log_data, headers=headers)
    
    if response.status_code == 201:
        print("Log saved successfully.")
        return response.json()  # คืนค่า response.json() ที่ได้จากการบันทึก log
    else:
        print(f"Error saving log: {response.status_code}, {response.text}")
    return None

# ฟังก์ชันหลัก
def main(request):
    try:
        # ดึงข้อมูล 3 วันที่ผ่านมา
        data_last_3_days = get_last_3_days_data_from_api()

        # ดึงข้อมูลราคาทองคำวันนี้จาก Web Scraping
        today_data = get_today_data()

        # ข้อมูลที่บันทึก log
        log_data = {
            "name": "Gold Data Fetch",
            "message": f"Fetched data for the last 3 days: {data_last_3_days}",
            "status": "201 create"
        }

        # บันทึก log ผ่าน API
        log_response = save_log_to_api(log_data)

        # บันทึกข้อมูลราคาทองคำวันนี้ลงใน API
        if today_data:
            save_today_data_to_api(today_data)

        # ส่งข้อมูล response กลับ
        if data_last_3_days and today_data:
            response_data = {
                "last_3_days_data": data_last_3_days,
                "today_data": today_data,
                "log": log_response  # รวมข้อมูล log ที่ได้จาก API
            }
            return json.dumps(response_data), 200
        else:
            return json.dumps({"error": "No data found for the last 3 days or today."}), 404

    except Exception as e:
        return json.dumps({"error": "An internal error occurred.", "details": str(e)}), 500